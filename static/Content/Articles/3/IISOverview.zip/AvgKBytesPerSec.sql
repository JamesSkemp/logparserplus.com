SELECT
TO_LOCALTIME(QUANTIZE(time, 1800)) as Hour,     --half hour
ADD(SCKBytesSec, CSKBytesSec) as KBytesSec
USING DIV(DIV(MUL(1.0, SUM(sc-bytes)), 1024), 3600) as SCKbytesSec,
DIV(DIV(MUL(1.0, SUM(cs-bytes)), 1024), 3600) as CSKBytesSec
INTO %outdirfile%
FROM %source%
GROUP BY Hour
ORDER BY Hour ASC
