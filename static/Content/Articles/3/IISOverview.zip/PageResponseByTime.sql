SELECT
TO_LOCALTIME(QUANTIZE(time, 1800)) as quantTime,
avg(time-taken) as AvgTime
INTO %outdirfile%
from %source% 
where TO_LOWERCASE(cs-uri-stem) = '%URI%' AND
sc-status < 400
group by TO_LOWERCASE(cs-uri-stem),quantTime
order by quantTime ASC
