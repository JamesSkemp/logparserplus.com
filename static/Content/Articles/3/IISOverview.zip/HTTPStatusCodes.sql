SELECT
    STRCAT(TO_STRING(sc-status), STRCAT('.', TO_STRING(sc-substatus))) AS Status,
    Count(*) as Hits
INTO %outdirfile%
FROM %source%
GROUP BY Status
ORDER BY Hits DESC
