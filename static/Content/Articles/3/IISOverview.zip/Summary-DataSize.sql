SELECT TOP 10
    DIV(ADD(SUM(cs-bytes), SUM(sc-bytes)), 1024) as totalKBytes,
    TO_LOWERCASE(EXTRACT_FILENAME(cs-uri-stem)) as URI,
    TO_LOWERCASE(EXTRACT_PATH(cs-uri-stem)) as Path,
    Count(*) as Hits
INTO %outdirfile%
FROM %source%
GROUP BY TO_LOWERCASE(EXTRACT_FILENAME(cs-uri-stem)), TO_LOWERCASE(EXTRACT_PATH(cs-uri-stem))
ORDER BY totalKBytes DESC

-- this should be similar to other summary but focus on avgerage response and slowest pages rather than most frequently requested pages.
