SELECT
    TOP 10 TO_LOWERCASE(cs-uri-stem) as URI,
    COUNT(*) as Hits,
    TO_LOWERCASE(EXTRACT_FILENAME(cs-uri-stem)) as filename

INTO %outdirfile%
FROM %source%
WHERE URI like '%.as%' AND
sc-status < 400 AND
cs-uri-stem NOT like '%serverstatus%' AND
cs-uri-stem NOT like '%keepalive%'
GROUP BY URI, filename
ORDER BY Hits DESC

