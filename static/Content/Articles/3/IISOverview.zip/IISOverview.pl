#!c:/perl/bin -w

my ($time, $file, $file2);

use strict;
use warnings;
use diagnostics;
use Win32::ODBC;

$time= scalar(localtime);
open (FILE, "c:\\Logparser\\iisoverview\\input\_parameters.txt") or die "Couldn't open input\_parameters.txt: $!; aborting";
while (<FILE>) {
     # if ($_ =~/(.*)\t(.*)\t(.*)/i) {       #tab delimited input
      if ($_ =~/(.*),(.*),(.*)/i) {          #comma delimited input
      chomp(my $server = $1);
      chomp(my $iisuser = $2);
      chomp(my $logdir = $3);
      my $outdir = "C:\\inetpub\\wwwroot\\IISOverview\\$server\\$iisuser";
      system ("md $outdir");
      system ("Logparser file:HTTPStatusCodes.sql\?source=\"$logdir\"+outdirfile=\"$outdir\\HTTPStatusCodes.gif\" -i:IISW3C -o:chart -chartType:Pie3D -groupSize:300x220 -values:OFF -chartTitle:\"\" -categories:OFF" or warn "$!\n");
      system ("Logparser file:AvgKBytesPerSec.sql\?source=\"$logdir\"+outdirfile=\"$outdir\\AvgKBytesPerSec.gif\" -i:IISW3C -o:chart -chartType:line -groupSize:555x220 -values:OFF -chartTitle:\"\" -categories:ON" or warn "$!\n");
      system ("Logparser file:HitsPer30min.sql\?source=\"$logdir\"+outdirfile=\"$outdir\\HitsPer30min.gif\" -i:IISW3C -o:chart -chartType:line -groupSize:555x220 -values:OFF -chartTitle:\"\" -categories:ON" or warn "$!\n");      
      system ("Logparser file:ErrorsPer30min.sql\?source=\"$logdir\"+outdirfile=\"$outdir\\ErrorsPer30min.gif\" -i:IISW3C -o:chart -chartType:line -groupSize:555x220 -values:OFF -chartTitle:\"\" -categories:ON" or warn "$!\n");
      system ("Logparser file:AvgResponsePer30min.sql\?source=\"$logdir\"+outdirfile=\"$outdir\\AvgResponsePer30min.gif\" -i:IISW3C -o:chart -chartType:line -groupSize:555x220 -values:OFF -chartTitle:\"\" -categories:ON" or warn "$!\n");      
      system ("Logparser file:RequestsByFiletype.sql\?source=\"$logdir\"+outdirfile=\"$outdir\\RequestsByFiletype.gif\" -i:IISW3C -o:chart -chartType:pie -groupSize:300x220 -chartTitle:\"\" -categories:OFF" or warn "$!\n");

      system ("Logparser file:Top10HitstoText.sql\?source=\"$logdir\"+outdirfile=\"$outdir\\Top10Hits.txt\" -i:IISW3C" or warn "$!\n");
      open (FILE2, "$outdir\\Top10Hits.txt") or warn "Couldn't open $outdir\\Top10Hits.txt: $!; aborting";
      while (<FILE2>) {
             if ($_ =~/(\/\S*)\s*(\d*)\s*(\S*)/i) {
             chomp(my $URI = $1);
             chomp(my $Hits = $2);
             chomp(my $filename = $3);
             my $outdirfile = "$outdir\\$filename.percent.response.gif";
             my $outdirfile2 = "$outdir\\$filename.avg.hourly.gif";
             print "$outdirfile\n";
             print "$URI";
             system ("Logparser file:PageResponseByPercent.sql\?source=\"$logdir\"+URI=\"$URI\"+filename=\"$filename\"+outdirfile=\"$outdirfile\" -i:IISW3C -o:chart -chartType:line -groupSize:900x300 -values:OFF -chartTitle:\"$filename\" -categories:ON" or warn "$!\n");
             system ("Logparser file:PageResponseByTime.sql\?source=\"$logdir\"+URI=\"$URI\"+filename=\"$filename\"+outdirfile=\"$outdirfile2\" -i:IISW3C -o:chart -chartType:line -groupSize:900x300 -values:OFF -chartTitle:\"$filename\" -categories:ON" or warn "$!\n");
             }
      }
close FILE2;

      system ("Logparser file:Top10ResponsetimetoText.sql\?source=\"$logdir\"+outdirfile=\"$outdir\\Top10Responsetime.txt\" -i:IISW3C" or warn "$!\n");
      open (FILE3, "$outdir\\Top10Responsetime.txt") or warn "Couldn't open $outdir\\Top10Responsetime.txt: $!; aborting";
      while (<FILE3>) {
             if ($_ =~/(\/\S*)\s*(\d*)\s*(\S*)/i) {
             chomp(my $URI = $1);
             chomp(my $Hits = $2);
             chomp(my $filename = $3);
             my $outdirfile = "$outdir\\$filename.percent.response.gif";
             my $outdirfile2 = "$outdir\\$filename.avg.hourly.gif";
             print "$outdirfile\n";
             print "$URI";
             system ("Logparser file:PageResponseByPercent.sql\?source=\"$logdir\"+URI=\"$URI\"+filename=\"$filename\"+outdirfile=\"$outdirfile\" -i:IISW3C -o:chart -chartType:line -groupSize:900x300 -values:OFF -chartTitle:\"$filename\" -categories:ON" or warn "$!\n");
             system ("Logparser file:PageResponseByTime.sql\?source=\"$logdir\"+URI=\"$URI\"+filename=\"$filename\"+outdirfile=\"$outdirfile2\" -i:IISW3C -o:chart -chartType:line -groupSize:900x300 -values:OFF -chartTitle:\"$filename\" -categories:ON" or warn "$!\n");
             }
      }
close FILE3;

      # Summary - this must be done after all other data is collected as it feeds it into the xsl
      system ("Logparser file:Summary-Index.sql\?source=\"$logdir\"+iisuser=\"$iisuser\"+server=\"$server\"+outdirfile=\"$outdir\\index.html\" -i:IISW3C -o:tpl -tpl:Summary-Index.tpl" or warn "$!\n");
      system ("Logparser file:Summary-Responsetime.sql\?source=\"$logdir\"+iisuser=\"$iisuser\"+server=\"$server\"+outdirfile=\"$outdir\\ResponseTime.html\" -i:IISW3C -o:tpl -tpl:Summary-Responsetime.tpl" or warn "$!\n");
      system ("Logparser file:Summary-Errors.sql\?source=\"$logdir\"+iisuser=\"$iisuser\"+server=\"$server\"+outdirfile=\"$outdir\\Errors.html\" -i:IISW3C -o:tpl -tpl:Summary-Errors.tpl" or warn "$!\n");
      system ("Logparser file:Summary-DataSize.sql\?source=\"$logdir\"+iisuser=\"$iisuser\"+server=\"$server\"+outdirfile=\"$outdir\\DataSize.html\" -i:IISW3C -o:tpl -tpl:Summary-DataSize.tpl" or warn "$!\n");
      }
}
close FILE;

