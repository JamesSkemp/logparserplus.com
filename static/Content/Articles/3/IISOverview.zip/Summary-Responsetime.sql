SELECT TOP 10
    avg(time-taken) as AvgResponse,
    TO_LOWERCASE(EXTRACT_FILENAME(cs-uri-stem)) as URI,
    TO_LOWERCASE(EXTRACT_PATH(cs-uri-stem)) as Path,
    Count(*) as Hits
INTO %outdirfile%
FROM %source%
WHERE cs-uri-stem like '%.as%' AND
sc-status < 400 AND
cs-uri-stem NOT like '%serverstatus%' AND
cs-uri-stem NOT like '%keepalive%'
GROUP BY TO_LOWERCASE(EXTRACT_FILENAME(cs-uri-stem)), TO_LOWERCASE(EXTRACT_PATH(cs-uri-stem))
HAVING COUNT(*) > 10
ORDER BY AvgResponse DESC

-- this should be similar to other summary but focus on avgerage response and slowest pages rather than most frequently requested pages.
