SELECT
TO_LOCALTIME(QUANTIZE(time, 1800)) as Hour,     --half hour
COUNT(*) as Hits
INTO %outdirfile%
FROM %source%
GROUP BY Hour
ORDER BY Hour ASC
