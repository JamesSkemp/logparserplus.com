SELECT TOP 50
QUANTIZE(time-taken, 100) as quantTime,
MUL(PROPCOUNT(*) ON (TO_LOWERCASE(cs-uri-stem)), 100) as percent
INTO %outdirfile%
from %source%
where TO_LOWERCASE(cs-uri-stem) = '%URI%' AND
sc-status < 400
group by TO_LOWERCASE(cs-uri-stem),quantTime
order by quantTime ASC
