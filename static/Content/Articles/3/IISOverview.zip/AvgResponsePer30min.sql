SELECT
TO_LOCALTIME(QUANTIZE(time, 1800)) as Hour,     --half hour
AVG(time-taken) as time
INTO %outdirfile%
FROM %source%
WHERE cs-uri-stem like '%.as%' AND
sc-status < 400
GROUP BY Hour
ORDER BY Hour ASC
