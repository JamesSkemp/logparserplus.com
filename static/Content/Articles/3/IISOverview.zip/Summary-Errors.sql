SELECT TOP 10
    STRCAT(TO_STRING(sc-status), STRCAT('.', TO_STRING(sc-substatus))) AS Status,
    TO_LOWERCASE(EXTRACT_FILENAME(cs-uri-stem)) as URI,
    TO_LOWERCASE(EXTRACT_PATH(cs-uri-stem)) as Path,
    Count(*) as Hits
INTO %outdirfile%
FROM %source%
WHERE sc-status > 399 AND
cs-uri-stem NOT like '%serverstatus%' AND
cs-uri-stem NOT like '%keepalive%'
GROUP BY TO_LOWERCASE(EXTRACT_FILENAME(cs-uri-stem)), TO_LOWERCASE(EXTRACT_PATH(cs-uri-stem)), Status
ORDER BY Hits DESC

-- this should be similar to other summary but focus on avgerage response and slowest pages rather than most frequently requested pages.
