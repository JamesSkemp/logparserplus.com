SELECT
    EXTRACT_EXTENSION(cs-uri-stem) as ext,
    COUNT(*) as  Hits
INTO %outdirfile%
FROM %source%
GROUP BY ext
ORDER BY Hits DESC
