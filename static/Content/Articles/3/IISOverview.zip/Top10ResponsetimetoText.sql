SELECT TOP 10 
       TO_LOWERCASE(cs-uri-stem) as URI,
       AVG(time-taken) as AvgResponse,
       TO_LOWERCASE(EXTRACT_FILENAME(cs-uri-stem)) as filename

INTO %outdirfile%
FROM %source%
WHERE URI like '%.as%' AND
sc-status < 400 AND
cs-uri-stem NOT like '%serverstatus%' AND
cs-uri-stem NOT like '%keepalive%'
GROUP BY URI, filename
HAVING COUNT(*) > 10
ORDER BY AvgResponse DESC

