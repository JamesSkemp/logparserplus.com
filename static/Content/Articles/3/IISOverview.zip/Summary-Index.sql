SELECT TOP 10
    TO_LOWERCASE(EXTRACT_FILENAME(cs-uri-stem)) as URI,
    TO_LOWERCASE(EXTRACT_PATH(cs-uri-stem)) as Path,
    avg(time-taken) as AvgResponse,
    Count(*) as Hits
INTO %outdirfile%
FROM %source%
WHERE cs-uri-stem like '%.as%' AND
sc-status < 400 AND
cs-uri-stem NOT like '%serverstatus%' AND
cs-uri-stem NOT like '%keepalive%'
GROUP BY TO_LOWERCASE(EXTRACT_FILENAME(cs-uri-stem)), TO_LOWERCASE(EXTRACT_PATH(cs-uri-stem))
ORDER BY Hits DESC
